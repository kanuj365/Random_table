var a = Math.floor(Math.random()*100+1)
// document.write(a)
function table(){
  for (var i =1;i<11;i++){
    document.write(a+"*"+i+"="+a*i+"<br/>")
  }
}
var time = setInterval(table,1000)
table()
clearInterval(time)